/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author sebas
 */
public class Ave extends Animal {
    
    private int año;
    private String propietario;
    public Ave(String nombre, double peso, int AÑO, String PROPIETARIO){
    super(nombre, peso);
    this.año = AÑO;
    this.propietario = PROPIETARIO;        
    
    }

    /**
     * @return the año
     */
    public int getAño() {
        return año;
    }

    /**
     * @param año the año to set
     */
    public void setAño(int año) {
        this.año = año;
    }

    /**
     * @return the propietario
     */
    public String getPropietario() {
        return propietario;
    }

    /**
     * @param propietario the propietario to set
     */
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }
    public void calcular(){
        int año_actual = 2025;
              int edad = año_actual-año;
              if(edad>=5){
                  System.out.println("Es mayor de edad");
              }else if(edad<=6){
                  System.out.println("Es menor de edad");
              }
          }  
}
 
        

